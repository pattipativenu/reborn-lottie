'use client';

import React, { useState } from 'react';
import HeroSection from './components/HeroSection';
import HowItWorksSection from './components/HowItWorksSection';
import ScrollExpansionHero from './components/ui/scroll-expansion-hero';
import { MouseTrackerProvider } from '@/components/ui/cursor';

function App() {
  const [heroComplete, setHeroComplete] = useState(false);
  const [pageInteractive, setPageInteractive] = useState(false);

  const handleHeroComplete = () => {
    setHeroComplete(true);
    setTimeout(() => {
      setPageInteractive(true);
    }, 300);
  };

  return (
    <MouseTrackerProvider>
      <div className="min-h-screen relative">
        {!heroComplete && (
          <HeroSection onComplete={handleHeroComplete} />
        )}

        {heroComplete && (
          <div
            className={`min-h-screen transition-opacity duration-500 ${
              heroComplete ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <HowItWorksSection isInteractive={pageInteractive} />

            <ScrollExpansionHero
              mediaType="image"
              mediaSrc="https://vleyzwirrsmwjotumxnf.supabase.co/storage/v1/object/public/assets//image-3.jpg"
            bgImageSrc="https://vleyzwirrsmwjotumxnf.supabase.co/storage/v1/object/public/assets//background.jpg"
              title="Most Loved Books"
              date="There is something new to learn"
              scrollToExpand="Scroll to expand and explore"
              textBlend={true}
            >
              <div className="bg-gradient-to-br from-blue-50 to-indigo-100 rounded-2xl p-8 shadow-lg">
                <div className="text-center">
                  <h2 
                    className="text-4xl font-bold text-gray-900 mb-6"
                    style={{ fontFamily: "'Poppins', sans-serif" }}
                  >
                    Discover Amazing Content
                  </h2>
                  <p 
                    className="text-lg text-gray-700 leading-relaxed mb-8 max-w-3xl mx-auto"
                    style={{ fontFamily: "'Inter', sans-serif" }}
                  >
                    This is a demonstration of the scroll expansion hero component. 
                    As you scrolled, the image expanded from a small preview to full screen 
                    while the text moved in opposite directions, creating an immersive and 
                    engaging user experience perfect for showcasing featured content.
                  </p>
                  
                  <div className="grid md:grid-cols-3 gap-6 mt-12">
                    <div className="bg-white rounded-xl p-6 shadow-md">
                      <div className="w-12 h-12 bg-blue-500 rounded-lg mb-4 mx-auto flex items-center justify-center">
                        <span className="text-white font-bold text-xl">1</span>
                      </div>
                      <h3 className="font-semibold text-gray-900 mb-2">Smooth Scrolling</h3>
                      <p className="text-gray-600 text-sm">Responsive scroll-based animations that work on all devices</p>
                    </div>
                    
                    <div className="bg-white rounded-xl p-6 shadow-md">
                      <div className="w-12 h-12 bg-green-500 rounded-lg mb-4 mx-auto flex items-center justify-center">
                        <span className="text-white font-bold text-xl">2</span>
                      </div>
                      <h3 className="font-semibold text-gray-900 mb-2">Media Expansion</h3>
                      <p className="text-gray-600 text-sm">Images and videos expand beautifully from preview to full screen</p>
                    </div>
                    
                    <div className="bg-white rounded-xl p-6 shadow-md">
                      <div className="w-12 h-12 bg-purple-500 rounded-lg mb-4 mx-auto flex items-center justify-center">
                        <span className="text-white font-bold text-xl">3</span>
                      </div>
                      <h3 className="font-semibold text-gray-900 mb-2">Text Animation</h3>
                      <p className="text-gray-600 text-sm">Dynamic text movements and fading effects for visual storytelling</p>
                    </div>
                  </div>
                </div>
              </div>
            </ScrollExpansionHero>
          </div>
        )}
      </div>
    </MouseTrackerProvider>
  );
}

export default App;