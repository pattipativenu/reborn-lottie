import React, { useState } from 'react';
import { Menu, X, Baby, BookOpen, User } from 'lucide-react';
import { LimelightNav } from '@/components/ui/limelight-nav';
import { PointerFollower } from '@/components/ui/cursor';

interface NavbarProps {
  isInteractive: boolean;
}

const Navbar: React.FC<NavbarProps> = ({ isInteractive }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    if (isInteractive) {
      setIsMobileMenuOpen(!isMobileMenuOpen);
    }
  };

  // Navigation items for LimelightNav with cursor labels
  const navItems = [
    { 
      id: 'kids', 
      icon: <Baby />, 
      label: 'Kids',
      onClick: () => console.log('Kids clicked')
    },
    { 
      id: 'library', 
      icon: <BookOpen />, 
      label: 'My Library',
      onClick: () => console.log('My Library clicked')
    },
    { 
      id: 'account', 
      icon: <User />, 
      label: 'Account',
      onClick: () => console.log('Account clicked')
    }
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black border-b border-gray-800/50">
      {/* Cursor Follower */}
      <PointerFollower />
      
      <div className="max-w-7xl mx-auto px-6 py-6">
        <div className="flex items-center justify-between">
          {/* Brand Name */}
          <div className="flex-shrink-0">
            <h1 
              className="text-white font-bold tracking-wider text-[29px]"
              style={{
                fontFamily: "'Poppins', sans-serif",
                letterSpacing: '1px'
              }}
            >
              REBORN
            </h1>
          </div>

          {/* Desktop Navigation with LimelightNav */}
          <div className="hidden md:flex items-center">
            {isInteractive ? (
              <LimelightNav
                items={navItems.map(item => ({
                  ...item,
                  icon: React.cloneElement(item.icon, {
                    onMouseEnter: () => document.documentElement.setAttribute("data-cursor-label", item.label),
                    onMouseLeave: () => document.documentElement.removeAttribute("data-cursor-label"),
                  })
                }))}
                defaultActiveIndex={0}
                className="bg-transparent border-gray-600/30"
                limelightClassName="bg-blue-500 shadow-[0_0_20px_rgba(59,130,246,0.8)]"
                iconClassName="text-white"
                iconContainerClassName="cursor-pointer"
              />
            ) : (
              <div className="flex items-center space-x-8">
                {navItems.map((item, index) => (
                  <div
                    key={item.id}
                    className="text-white font-medium opacity-70 cursor-default flex items-center space-x-2"
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: '1rem',
                      fontWeight: '500'
                    }}
                  >
                    <item.icon.type className="w-5 h-5" />
                    <span>{item.label}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={toggleMobileMenu}
              className={`text-white p-2 transition-colors duration-300 ${
                isInteractive 
                  ? 'hover:text-blue-400 cursor-pointer' 
                  : 'cursor-default opacity-70'
              }`}
              disabled={!isInteractive}
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && isInteractive && (
          <div className="md:hidden mt-4 pb-4 border-t border-gray-700/50">
            <div className="flex flex-col space-y-4 pt-4">
              {navItems.map((item, index) => (
                <a
                  key={item.id}
                  href="#"
                  className="text-white font-medium hover:text-blue-400 transition-colors duration-300 py-2 flex items-center space-x-3"
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontSize: '1rem',
                    fontWeight: '500'
                  }}
                  onClick={(e) => {
                    e.preventDefault();
                    item.onClick?.();
                  }}
                  onMouseEnter={() => document.documentElement.setAttribute("data-cursor-label", item.label)}
                  onMouseLeave={() => document.documentElement.removeAttribute("data-cursor-label")}
                >
                  <item.icon.type className="w-5 h-5" />
                  <span>{item.label}</span>
                </a>
              ))}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;