import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { MagnetizeButton } from '@/components/ui/magnetize-button';
import { TextRotate } from '@/components/ui/text-rotate';

interface HeroSectionProps {
  onComplete: () => void;
}

const HeroSection: React.FC<HeroSectionProps> = ({ onComplete }) => {
  const [showContent, setShowContent] = useState(false);
  const [hideButton, setHideButton] = useState(false);
  const [fadeText, setFadeText] = useState(false);
  const [fadeBackground, setFadeBackground] = useState(false);
  
  const loopingWords = ['Learn', 'Apply', 'Understand'];

  // Fast loading - everything loads within 2 seconds
  useEffect(() => {
    const loadTimer = setTimeout(() => {
      setShowContent(true);
    }, 200); // Very fast initial load - 0.2 seconds

    return () => clearTimeout(loadTimer);
  }, []);

  // Handle Enter key press
  const handleKeyPress = useCallback((event: KeyboardEvent) => {
    if (event.key === 'Enter' && showContent && !hideButton) {
      startFadeSequence();
    }
  }, [showContent, hideButton]);

  // Handle button click
  const handleButtonClick = useCallback(() => {
    if (showContent && !hideButton) {
      startFadeSequence();
    }
  }, [showContent, hideButton]);

  const startFadeSequence = useCallback(() => {
    // Step 1: Hide button immediately
    setHideButton(true);
    
    // Step 2: Start text fade after small delay
    setTimeout(() => {
      setFadeText(true);
    }, 100);
    
    // Step 3: Start background fade after text fade completes
    setTimeout(() => {
      setFadeBackground(true);
    }, 2500); // Text fade duration + buffer
    
    // Step 4: Complete transition and notify parent
    setTimeout(() => {
      onComplete();
    }, 5000); // Total duration
  }, [onComplete]);

  useEffect(() => {
    document.addEventListener('keydown', handleKeyPress);
    return () => document.removeEventListener('keydown', handleKeyPress);
  }, [handleKeyPress]);

  // Loading state
  if (!showContent) {
    return (
      <div className="h-screen bg-black flex items-center justify-center">
        <div className="text-white opacity-50">Loading...</div>
      </div>
    );
  }

  return (
    <div className="relative h-screen overflow-hidden">
      {/* Original Hero Content */}
      <div className="relative h-screen flex items-center justify-center overflow-hidden bg-black">
        
        {/* Background Image with Sequential Fade Effect */}
        <div 
          className={`absolute inset-0 transition-opacity duration-[2500ms] ease-out ${
            fadeBackground ? 'opacity-0' : 'opacity-100'
          }`}
          style={{
            backgroundImage: 'url("https://github.com/pattipativenu/reborn-lottie/blob/main/perplixity-2.jpg?raw=true")',
            backgroundSize: 'cover',
            backgroundPosition: 'center center',
            backgroundRepeat: 'no-repeat'
          }}
        />

        {/* Gradient Overlay with Sequential Fade */}
        <div 
          className={`absolute inset-0 z-10 transition-opacity duration-[2500ms] ease-out ${
            fadeBackground ? 'opacity-0' : 'opacity-100'
          }`}
          style={{
            background: 'linear-gradient(to top, rgba(0,0,0,0.7), rgba(0,0,0,0.1))'
          }}
        />
        
        {/* Main Content - SMOOTH TEXT FADE */}
        <div className={`relative z-20 max-w-4xl mx-auto px-8 text-center transition-opacity duration-[2000ms] ease-out ${
          fadeText ? 'opacity-0 pointer-events-none' : 'opacity-100'
        }`}>
          
          {/* Centered Hero Heading with Smooth Text Rotation */}
          <div className="mb-8 flex flex-col items-center justify-center">
            <div className="mb-6">
              <TextRotate
                texts={loopingWords}
                rotationInterval={4000}
                transition={{ type: "spring", damping: 30, stiffness: 400 }}
                initial={{ y: "100%", opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: "-120%", opacity: 0 }}
                splitBy="characters"
                staggerDuration={0.12}
                staggerFrom="first"
                mainClassName="font-bold mb-0 flex justify-center"
                elementLevelClassName="inline-block"
                style={{
                  fontFamily: "'Poppins', sans-serif",
                  fontSize: 'clamp(2.5rem, 7vw, 4rem)',
                  lineHeight: '1',
                  letterSpacing: '-1px',
                  backgroundImage: 'linear-gradient(135deg, #FFB366 0%, #FF8C42 25%, #FF6B1A 50%, #E55A00 75%, #CC4F00 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                  textAlign: 'center'
                }}
              />
            </div>
            
            <h2 
              className="font-bold text-white"
              style={{
                fontFamily: "'Poppins', sans-serif",
                fontSize: 'clamp(2.5rem, 7vw, 4rem)',
                lineHeight: '1.2',
                letterSpacing: '-0.5px'
              }}
            >
              Something new every day
            </h2>
          </div>

          {/* Tagline */}
          <p 
            className="text-gray-100 mb-8 max-w-2xl mx-auto"
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 'clamp(1rem, 2.5vw, 1.25rem)',
              lineHeight: '1.5',
              letterSpacing: '0.25px',
              fontWeight: '500'
            }}
          >
            "The world's first podcast-style audiobook platform with real-time examples."
          </p>

          {/* Magnetize Enter Button - HIDDEN IMMEDIATELY AFTER ENTER */}
          <div className={`transition-opacity duration-300 ease-out ${hideButton ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
            <MagnetizeButton
              onClick={handleButtonClick}
              particleCount={14}
              attractRadius={80}
              className="px-8 py-4 rounded-full"
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: '1.1rem',
                letterSpacing: '0.5px',
                fontWeight: '600'
              }}
            >
              Enter
            </MagnetizeButton>
          </div>
        </div>
          
        {/* Subtle Animation Background Elements with Sequential Fade */}
        <div className={`absolute inset-0 z-0 transition-opacity duration-[2500ms] ease-out ${
          fadeBackground ? 'opacity-0' : 'opacity-100'
        }`}>
          <motion.div
            animate={{
              scale: [1, 1.1, 1],
              opacity: [0.1, 0.2, 0.1]
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="absolute top-1/4 left-1/4 w-64 h-64 bg-blue-500 rounded-full blur-3xl"
          />
          <motion.div
            animate={{
              scale: [1.1, 1, 1.1],
              opacity: [0.1, 0.15, 0.1]
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 2
            }}
            className="absolute bottom-1/4 right-1/4 w-48 h-48 bg-yellow-400 rounded-full blur-3xl"
          />
        </div>
      </div>
    </div>
  );
};

export default HeroSection;