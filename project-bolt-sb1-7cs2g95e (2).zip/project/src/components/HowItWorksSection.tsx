import React from 'react';
import { motion } from 'framer-motion';
import Navbar from './Navbar';
import CardSwap, { Card } from '@/components/ui/card-swap';

interface HowItWorksSectionProps {
  isInteractive: boolean;
}

const HowItWorksSection: React.FC<HowItWorksSectionProps> = ({ isInteractive }) => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3,
        delayChildren: 0.2
      }
    }
  };

  const textVariants = {
    hidden: { 
      opacity: 0, 
      y: 30
    },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 20,
        duration: 0.8
      }
    }
  };

  const cardData = [
    {
      heading: "Pick a Book",
      paragraph: "Choose from our curated list of engaging books.",
      videoUrl: "https://github.com/pattipativenu/reborn-lottie/blob/main/books.mp4?raw=true"
    },
    {
      heading: "Listen & Interact", 
      paragraph: "Enjoy podcast-style audio with real-world examples.",
      videoUrl: "https://github.com/pattipativenu/reborn-lottie/blob/main/listen.mp4?raw=true"
    },
    {
      heading: "Test & Grow",
      paragraph: "Take quizzes and track your progress as you learn.",
      videoUrl: "https://github.com/pattipativenu/reborn-lottie/blob/main/prize.mp4?raw=true"
    }
  ];

  return (
    <div className="h-screen bg-white relative overflow-hidden">
      {/* Fixed Navbar */}
      <Navbar isInteractive={isInteractive} />
      
      {/* Main Content - Side by Side Layout - Full Screen */}
      <div className="h-full flex items-center justify-center pt-24 px-6 lg:px-8">
        <div className="max-w-7xl w-full h-full">
          <motion.div
            className="grid lg:grid-cols-2 gap-16 items-center h-full"
            variants={containerVariants}
            initial="hidden"
            animate={isInteractive ? "visible" : "hidden"}
          >
            
            {/* Left Side - Heading and Tagline */}
            <motion.div 
              className="flex flex-col justify-center h-full"
              variants={textVariants}
            >
              <h2 
                className="text-5xl lg:text-6xl xl:text-7xl font-bold text-gray-900 mb-8"
                style={{
                  fontFamily: "'Poppins', sans-serif",
                  lineHeight: '1.1',
                  textAlign: 'left'
                }}
              >
                How Reborn Works
              </h2>
              
              <p 
                className="text-gray-600 text-xl lg:text-2xl leading-relaxed max-w-lg"
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: '1.25rem',
                  lineHeight: '1.6',
                  textAlign: 'left'
                }}
              >
                "Transform your learning journey with our simple three-step process"
              </p>
            </motion.div>

            {/* Right Side - Card Stack (Desktop) */}
            <motion.div 
              className="hidden lg:flex justify-center items-center h-full"
              variants={textVariants}
              initial="hidden"
              animate={isInteractive ? "visible" : "hidden"}
            >
              <div className="relative">
                <CardSwap
                  width={480}
                  height={380}
                  cardDistance={40}
                  verticalDistance={45}
                  delay={4000}
                  pauseOnHover={isInteractive}
                  easing="power"
                >
                  {cardData.map((card, index) => (
                    <Card key={index}>
                      <div className="relative h-full w-full overflow-hidden rounded-xl">
                        {/* Background Video - Full Coverage */}
                        <video
                          className="absolute inset-0 w-full h-full object-cover"
                          autoPlay
                          loop
                          muted
                          playsInline
                        >
                          <source src={card.videoUrl} type="video/mp4" />
                          Your browser does not support the video tag.
                        </video>
                        
                        {/* Content Overlay - Positioned at Bottom */}
                        <div className="absolute bottom-0 left-0 right-0 p-6">
                          {/* Semi-transparent Background for Text */}
                          <div className="bg-black/60 backdrop-blur-sm rounded-lg p-4">
                            <h3 
                              className="font-bold mb-2 text-white text-xl"
                              style={{
                                fontFamily: "'Poppins', sans-serif",
                                fontSize: '1.25rem'
                              }}
                            >
                              {card.heading}
                            </h3>
                            <p 
                              className="text-gray-100 text-base leading-relaxed"
                              style={{
                                fontFamily: "'Inter', sans-serif",
                                fontSize: '1rem',
                                lineHeight: '1.5'
                              }}
                            >
                              {card.paragraph}
                            </p>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </CardSwap>
              </div>
            </motion.div>

            {/* Mobile Layout - Static Cards */}
            <motion.div className="lg:hidden space-y-6 w-full col-span-2 py-8" variants={textVariants}>
              {cardData.map((card, index) => (
                <div
                  key={index}
                  className="relative rounded-xl shadow-sm border-2 border-transparent overflow-hidden
                  transition-all duration-300 ease-in-out
                  hover:border-blue-600 hover:shadow-[0_6px_24px_rgba(37,99,235,0.25)] hover:scale-[1.03]"
                  style={{ height: '280px' }}
                >
                  {/* Background Video - Full Coverage */}
                  <video
                    className="absolute inset-0 w-full h-full object-cover"
                    autoPlay
                    loop
                    muted
                    playsInline
                  >
                    <source src={card.videoUrl} type="video/mp4" />
                    Your browser does not support the video tag.
                  </video>
                  
                  {/* Content Overlay - Positioned at Bottom */}
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    {/* Semi-transparent Background for Text */}
                    <div className="bg-black/60 backdrop-blur-sm rounded-lg p-4">
                      <h3 
                        className="text-white font-bold mb-2"
                        style={{
                          fontFamily: "'Poppins', sans-serif",
                          fontSize: '1.25rem'
                        }}
                      >
                        {card.heading}
                      </h3>
                      <p 
                        className="text-gray-100"
                        style={{
                          fontFamily: "'Inter', sans-serif",
                          fontSize: '1rem',
                          lineHeight: '1.6'
                        }}
                      >
                        {card.paragraph}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default HowItWorksSection;