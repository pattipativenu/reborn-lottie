"use client" 

import * as React from "react"

import { cn } from "@/lib/utils";
import { motion, useAnimation, useMotionValue, useSpring, useTransform } from "framer-motion";
import { useEffect, useState, useCallback, useRef } from "react";
import { Button } from "@/components/ui/button";

interface MagnetizeButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
    particleCount?: number;
    attractRadius?: number;
}

interface Particle {
    id: number;
    x: number;
    y: number;
}

function MagnetizeButton({
    className,
    particleCount = 12,
    attractRadius = 50,
    children,
    ...props
}: MagnetizeButtonProps) {
    const [isAttracting, setIsAttracting] = useState(false);
    const [particles, setParticles] = useState<Particle[]>([]);
    const particlesControl = useAnimation();
    const buttonRef = useRef<HTMLButtonElement>(null);
    
    // Mouse position tracking
    const mouseX = useMotionValue(0);
    const mouseY = useMotionValue(0);
    
    // Spring animations for smooth magnetic effect
    const springConfig = { damping: 25, stiffness: 150 };
    const x = useSpring(mouseX, springConfig);
    const y = useSpring(mouseY, springConfig);
    
    // Transform values for magnetic attraction
    const rotateX = useTransform(y, [-100, 100], [30, -30]);
    const rotateY = useTransform(x, [-100, 100], [-30, 30]);

    useEffect(() => {
        const newParticles = Array.from({ length: particleCount }, (_, i) => ({
            id: i,
            x: Math.random() * 360 - 180,
            y: Math.random() * 360 - 180,
        }));
        setParticles(newParticles);
    }, [particleCount]);

    const handleMouseMove = useCallback((event: React.MouseEvent) => {
        if (!buttonRef.current) return;
        
        const rect = buttonRef.current.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        
        const deltaX = event.clientX - centerX;
        const deltaY = event.clientY - centerY;
        
        // Apply magnetic effect within attract radius
        const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
        if (distance < attractRadius) {
            const strength = 1 - distance / attractRadius;
            mouseX.set(deltaX * strength * 0.5);
            mouseY.set(deltaY * strength * 0.5);
        } else {
            mouseX.set(0);
            mouseY.set(0);
        }
    }, [attractRadius, mouseX, mouseY]);

    const handleInteractionStart = useCallback(async () => {
        setIsAttracting(true);
        await particlesControl.start({
            x: 0,
            y: 0,
            transition: {
                type: "spring",
                stiffness: 50,
                damping: 10,
            },
        });
    }, [particlesControl]);

    const handleInteractionEnd = useCallback(async () => {
        setIsAttracting(false);
        mouseX.set(0);
        mouseY.set(0);
        await particlesControl.start((i) => ({
            x: particles[i]?.x || 0,
            y: particles[i]?.y || 0,
            transition: {
                type: "spring",
                stiffness: 100,
                damping: 15,
            },
        }));
    }, [particlesControl, particles, mouseX, mouseY]);

    return (
        <motion.div
            style={{ x, y, rotateX, rotateY }}
            onMouseMove={handleMouseMove}
            className="inline-block"
        >
            <Button
                ref={buttonRef}
                className={cn(
                    "min-w-40 relative touch-none rounded-xl",
                    "bg-blue-600 hover:bg-blue-700",
                    "text-white font-semibold uppercase",
                    "transition-all duration-300",
                    "transform-gpu perspective-1000",
                    className
                )}
                onMouseEnter={handleInteractionStart}
                onMouseLeave={handleInteractionEnd}
                onTouchStart={handleInteractionStart}
                onTouchEnd={handleInteractionEnd}
                {...props}
            >
                {particles.map((_, index) => (
                    <motion.div
                        key={index}
                        custom={index}
                        initial={{ x: particles[index]?.x || 0, y: particles[index]?.y || 0 }}
                        animate={particlesControl}
                        className={cn(
                            "absolute w-1.5 h-1.5 rounded-full",
                            "bg-blue-300",
                            "transition-opacity duration-300",
                            isAttracting ? "opacity-100" : "opacity-0"
                        )}
                    />
                ))}
                <span className="relative w-full flex items-center justify-center gap-2">
                    {children || "Enter"}
                </span>
            </Button>
        </motion.div>
    );
}

export { MagnetizeButton }