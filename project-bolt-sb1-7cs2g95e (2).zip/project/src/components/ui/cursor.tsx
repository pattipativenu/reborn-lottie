import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';

// Mouse position context
interface MousePosition {
  x: number;
  y: number;
}

const MouseTrackerContext = createContext<MousePosition>({ x: 0, y: 0 });

// Provider component
interface MouseTrackerProviderProps {
  children: ReactNode;
}

export const MouseTrackerProvider: React.FC<MouseTrackerProviderProps> = ({ children }) => {
  const [mousePosition, setMousePosition] = useState<MousePosition>({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (event: MouseEvent) => {
      setMousePosition({
        x: event.clientX,
        y: event.clientY,
      });
    };

    document.addEventListener('mousemove', handleMouseMove);
    return () => document.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <MouseTrackerContext.Provider value={mousePosition}>
      {children}
    </MouseTrackerContext.Provider>
  );
};

// Hook to use mouse position
export const useMousePosition = () => {
  return useContext(MouseTrackerContext);
};

// Pointer follower component
export const PointerFollower: React.FC = () => {
  const mousePosition = useMousePosition();
  const [label, setLabel] = useState<string>('');
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const checkForLabel = () => {
      const cursorLabel = document.documentElement.getAttribute('data-cursor-label');
      if (cursorLabel && cursorLabel !== label) {
        setLabel(cursorLabel);
        setIsVisible(true);
      } else if (!cursorLabel && isVisible) {
        setIsVisible(false);
        // Small delay before clearing label to allow for smooth fade out
        setTimeout(() => setLabel(''), 150);
      }
    };

    // Check immediately
    checkForLabel();

    // Set up observer for attribute changes
    const observer = new MutationObserver(checkForLabel);
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['data-cursor-label']
    });

    return () => observer.disconnect();
  }, [label, isVisible]);

  if (!label) return null;

  return (
    <div
      className={`fixed pointer-events-none z-[9999] transition-all duration-200 ease-out ${
        isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
      }`}
      style={{
        left: '50%',
        top: mousePosition.y + 24, // Position below cursor with 24px offset
        transform: `translateX(-50%) translateZ(0)`, // Center horizontally and force hardware acceleration
        marginLeft: mousePosition.x - window.innerWidth / 2, // Adjust horizontal position based on cursor
      }}
    >
      <div
        className="pointer-follower-label px-3 py-2 rounded-lg shadow-lg text-sm font-medium whitespace-nowrap animate-in fade-in-0 zoom-in-95 duration-200"
        style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: '0.875rem',
          backgroundColor: '#1f2937',
          color: 'white',
          boxShadow: '0 4px 12px rgba(0,0,0,0.2)',
        }}
      >
        {label}
      </div>
    </div>
  );
};