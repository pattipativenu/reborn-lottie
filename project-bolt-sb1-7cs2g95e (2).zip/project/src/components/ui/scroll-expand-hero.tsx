import React from 'react';
import ScrollExpandMedia from './scroll-expand-media';

const ScrollExpandHero = () => {
  return (
    <ScrollExpandMedia
      mediaType="video"
      mediaSrc="https://github.com/pattipativenu/reborn-lottie/blob/main/video%20for%20most%20loved%20books.mp4?raw=true"
      bgImageSrc="https://github.com/pattipativenu/reborn-lottie/blob/main/image%20-6.jpg?raw=true"
      title="Most Loved Books"
      date="There is always something to learn"
      scrollToExpand=""
      textBlend={true}
    >
      {/* Content that appears after video fully expands */}
      <div className="bg-black/70 backdrop-blur-sm py-12 rounded-lg">
        <div className="max-w-4xl mx-auto text-center px-6">
          <h2 className="text-3xl font-bold text-white mb-6" style={{ fontFamily: "'Poppins', sans-serif" }}>
            About this component
          </h2>
          <p className="text-lg text-gray-200 leading-relaxed mb-8" style={{ fontFamily: "'Inter', sans-serif" }}>
            This is a demonstration of this scroll extension media component with a video.
          </p>
        </div>
      </div>
    </ScrollExpandMedia>
  );
};

export default ScrollExpandHero;