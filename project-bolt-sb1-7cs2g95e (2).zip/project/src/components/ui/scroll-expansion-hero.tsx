'use client';

import {
  useEffect,
  useRef,
  useState,
  ReactNode,
} from 'react';
import { motion } from 'framer-motion';

interface ScrollExpansionHeroProps {
  mediaType?: 'video' | 'image';
  mediaSrc: string;
  posterSrc?: string;
  bgImageSrc: string;
  title?: string;
  date?: string;
  scrollToExpand?: string;
  textBlend?: boolean;
  children?: ReactNode;
}

const ScrollExpansionHero = ({
  mediaType = 'image',
  mediaSrc,
  posterSrc,
  bgImageSrc,
  title,
  date,
  scrollToExpand,
  textBlend = false,
  children,
}: ScrollExpansionHeroProps) => {
  const [scrollProgress, setScrollProgress] = useState(0);
  const [showContent, setShowContent] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      if (!triggerRef.current) return;
      const rect = triggerRef.current.getBoundingClientRect();
      if (rect.top <= window.innerHeight) {
        const progress = Math.min(Math.max((window.innerHeight - rect.top) / rect.height, 0), 1);
        setScrollProgress(progress);
        if (progress >= 1) {
          setIsExpanded(true);
          setShowContent(true);
        } else if (progress < 0.8) {
          setShowContent(false);
          setIsExpanded(false);
        }
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const baseWidth = 300;
  const baseHeight = 400;
  const maxWidth = isMobile ? window.innerWidth * 0.95 : window.innerWidth;
  const maxHeight = isMobile ? window.innerHeight * 0.85 : window.innerHeight;
  const mediaWidth = baseWidth + (maxWidth - baseWidth) * scrollProgress;
  const mediaHeight = baseHeight + (maxHeight - baseHeight) * scrollProgress;
  const textOpacity = Math.max(1 - scrollProgress * 1.5, 0);
  const textTranslateX = scrollProgress * (isMobile ? 100 : 150);
  const titleWords = title ? title.split(' ') : [];
  const firstPart = titleWords.slice(0, Math.ceil(titleWords.length / 2)).join(' ');
  const secondPart = titleWords.slice(Math.ceil(titleWords.length / 2)).join(' ');

  return (
    <div ref={sectionRef} className="relative min-h-screen overflow-hidden">
      <motion.div
        className="absolute inset-0 z-0"
        animate={{ opacity: 1 - scrollProgress }}
        transition={{ duration: 0.1 }}
        style={{ pointerEvents: 'none' }}
      >
        {mediaType === 'video' ? (
          <video
            src={bgImageSrc}
            autoPlay
            muted
            loop
            playsInline
            className="w-full h-full object-cover"
          />
        ) : (
          <img src={bgImageSrc} alt="Background" className="w-full h-full object-cover" />
        )}
        <div className="absolute inset-0 bg-black/20" />
      </motion.div>

      <div ref={triggerRef} className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4">
        <div
          className="relative rounded-2xl overflow-hidden shadow-2xl transition-none"
          style={{
            width: `${mediaWidth}px`,
            height: `${mediaHeight}px`,
            maxWidth: '95vw',
            maxHeight: '85vh',
          }}
        >
          {mediaType === 'video' ? (
            <video
              src={mediaSrc}
              poster={posterSrc}
              autoPlay
              muted
              loop
              playsInline
              className="w-full h-full object-cover"
              style={{ borderRadius: scrollProgress > 0.9 ? '0px' : '16px' }}
            />
          ) : (
            <img
              src={mediaSrc}
              alt={title || 'Media content'}
              className="w-full h-full object-cover"
              style={{ borderRadius: scrollProgress > 0.9 ? '0px' : '16px' }}
            />
          )}

          <motion.div
            className="absolute inset-0 bg-black/30"
            animate={{ opacity: 0.4 - scrollProgress * 0.4 }}
            transition={{ duration: 0.2 }}
          />
        </div>

        <div
          className={`absolute inset-0 flex flex-col items-center justify-center text-center z-50 pointer-events-none ${
            textBlend ? 'mix-blend-difference' : ''
          }`}
          style={{ opacity: textOpacity }}
        >
          {title && (
            <div className="mb-4">
              <motion.h1
                className="text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold text-white mb-2"
                style={{
                  transform: `translateX(-${textTranslateX}px)`,
                  fontFamily: "'Poppins', sans-serif",
                  textShadow: '2px 2px 4px rgba(0,0,0,0.8)',
                }}
              >
                {firstPart}
              </motion.h1>
              <motion.h1
                className="text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold text-white"
                style={{
                  transform: `translateX(${textTranslateX}px)`,
                  fontFamily: "'Poppins', sans-serif",
                  textShadow: '2px 2px 4px rgba(0,0,0,0.8)',
                }}
              >
                {secondPart}
              </motion.h1>
            </div>
          )}

          {date && (
            <motion.p
              className="text-xl md:text-2xl text-blue-200 font-medium mb-2"
              style={{
                transform: `translateX(-${textTranslateX * 0.7}px)`,
                fontFamily: "'Inter', sans-serif",
                textShadow: '1px 1px 2px rgba(0,0,0,0.8)',
              }}
            >
              {date}
            </motion.p>
          )}

          {scrollToExpand && (
            <motion.p
              className="text-lg text-blue-200 font-medium"
              style={{
                transform: `translateX(${textTranslateX * 0.7}px)`,
                fontFamily: "'Inter', sans-serif",
                textShadow: '1px 1px 2px rgba(0,0,0,0.8)',
              }}
            >
              {scrollToExpand}
            </motion.p>
          )}
        </div>

        {!isExpanded && scrollProgress < 0.1 && (
          <motion.div
            className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-40"
            animate={{ opacity: 1 - scrollProgress * 5 }}
          >
            <div className="flex flex-col items-center text-white/80">
              <p className="text-sm mb-2" style={{ fontFamily: "'Inter', sans-serif" }}>
                Scroll to expand
              </p>
              <motion.div
                animate={{ y: [0, 8, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center"
              >
                <div className="w-1 h-3 bg-white/50 rounded-full mt-2" />
              </motion.div>
            </div>
          </motion.div>
        )}
      </div>

      <motion.div
        className="relative z-20 bg-white"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: showContent ? 1 : 0, y: showContent ? 0 : 50 }}
        transition={{ duration: 0.8, delay: 0.3 }}
      >
        {showContent && <div className="max-w-4xl mx-auto px-6 py-16">{children}</div>}
      </motion.div>
    </div>
  );
};

export default ScrollExpansionHero;