import {
  useEffect,
  useRef,
  useState,
  ReactNode,
} from 'react';
import { motion } from 'framer-motion';

interface ScrollExpandMediaProps {
  mediaType?: 'video' | 'image';
  mediaSrc: string;
  posterSrc?: string;
  bgImageSrc: string;
  title?: string;
  date?: string;
  scrollToExpand?: string;
  textBlend?: boolean;
  children?: ReactNode;
}

const ScrollExpandMedia = ({
  mediaType = 'video',
  mediaSrc,
  posterSrc,
  bgImageSrc,
  title,
  date,
  scrollToExpand,
  textBlend,
  children,
}: ScrollExpandMediaProps) => {
  const [scrollProgress, setScrollProgress] = useState<number>(0);
  const [showContent, setShowContent] = useState<boolean>(false);
  const [isVideoExpanded, setIsVideoExpanded] = useState<boolean>(false);
  const [isScrollLocked, setIsScrollLocked] = useState<boolean>(false);
  const [accumulatedScroll, setAccumulatedScroll] = useState<number>(0);

  const sectionRef = useRef<HTMLDivElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Reset states when component mounts
  useEffect(() => {
    setScrollProgress(0);
    setShowContent(false);
    setIsVideoExpanded(false);
    setIsScrollLocked(false);
    setAccumulatedScroll(0);
    document.body.style.overflow = 'auto';
  }, []);

  // Intersection Observer to detect when section is in view
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && entry.intersectionRatio > 0.8) {
          // User has scrolled to the bottom of the books section
          setIsScrollLocked(true);
          document.body.style.overflow = 'hidden';
        } else if (!entry.isIntersecting && !isVideoExpanded) {
          // User has scrolled away and video is not expanded
          setIsScrollLocked(false);
          document.body.style.overflow = 'auto';
          setScrollProgress(0);
          setAccumulatedScroll(0);
        }
      },
      { 
        threshold: [0, 0.8, 1],
        rootMargin: '-10px'
      }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      observer.disconnect();
      document.body.style.overflow = 'auto';
    };
  }, [isVideoExpanded]);

  // Handle wheel events for video expansion
  useEffect(() => {
    const handleWheel = (e: WheelEvent) => {
      if (!isScrollLocked) return;

      e.preventDefault();
      
      const scrollDelta = e.deltaY;
      const newAccumulated = accumulatedScroll + scrollDelta;
      
      if (isVideoExpanded && scrollDelta > 0) {
        // Allow normal scrolling when video is expanded and user scrolls down
        setIsScrollLocked(false);
        document.body.style.overflow = 'auto';
        return;
      }
      
      if (isVideoExpanded && scrollDelta < 0 && scrollProgress > 0) {
        // Allow shrinking video when scrolling up
        const newProgress = Math.max(scrollProgress - Math.abs(scrollDelta) * 0.002, 0);
        setScrollProgress(newProgress);
        setAccumulatedScroll(newAccumulated);
        
        if (newProgress < 0.95) {
          setIsVideoExpanded(false);
          setShowContent(false);
        }
        return;
      }
      
      if (!isVideoExpanded && scrollDelta > 0) {
        // Expand video when scrolling down
        const maxScroll = 1000; // Amount of scroll needed for full expansion
        const newProgress = Math.min(newAccumulated / maxScroll, 1);
        
        setScrollProgress(newProgress);
        setAccumulatedScroll(newAccumulated);
        
        if (newProgress >= 0.95) {
          setIsVideoExpanded(true);
          setShowContent(true);
        }
      } else if (!isVideoExpanded && scrollDelta < 0 && accumulatedScroll > 0) {
        // Allow shrinking when scrolling up
        const newProgress = Math.max(newAccumulated / 1000, 0);
        setScrollProgress(newProgress);
        setAccumulatedScroll(Math.max(newAccumulated, 0));
      }
    };

    window.addEventListener('wheel', handleWheel, { passive: false });

    return () => {
      window.removeEventListener('wheel', handleWheel);
    };
  }, [isScrollLocked, isVideoExpanded, scrollProgress, accumulatedScroll]);

  // Handle touch events for mobile
  useEffect(() => {
    let touchStartY = 0;
    let touchStartTime = 0;

    const handleTouchStart = (e: TouchEvent) => {
      if (!isScrollLocked) return;
      touchStartY = e.touches[0].clientY;
      touchStartTime = Date.now();
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (!isScrollLocked) return;
      
      e.preventDefault();
      
      const touchY = e.touches[0].clientY;
      const deltaY = touchStartY - touchY;
      const touchTime = Date.now() - touchStartTime;
      
      if (touchTime < 50) return; // Debounce rapid touches
      
      if (isVideoExpanded && deltaY < -20) {
        // Allow normal scrolling when swiping down from expanded video
        setIsScrollLocked(false);
        document.body.style.overflow = 'auto';
        return;
      }
      
      if (isVideoExpanded && deltaY > 20 && scrollProgress > 0) {
        // Allow shrinking video when swiping up
        const newProgress = Math.max(scrollProgress - Math.abs(deltaY) * 0.003, 0);
        setScrollProgress(newProgress);
        
        if (newProgress < 0.95) {
          setIsVideoExpanded(false);
          setShowContent(false);
        }
        return;
      }
      
      if (!isVideoExpanded && deltaY > 20) {
        // Expand video when swiping up
        const newAccumulated = accumulatedScroll + deltaY * 2;
        const newProgress = Math.min(newAccumulated / 1000, 1);
        
        setScrollProgress(newProgress);
        setAccumulatedScroll(newAccumulated);
        
        if (newProgress >= 0.95) {
          setIsVideoExpanded(true);
          setShowContent(true);
        }
      }
      
      touchStartY = touchY;
      touchStartTime = Date.now();
    };

    window.addEventListener('touchstart', handleTouchStart as any, { passive: false });
    window.addEventListener('touchmove', handleTouchMove as any, { passive: false });

    return () => {
      window.removeEventListener('touchstart', handleTouchStart as any);
      window.removeEventListener('touchmove', handleTouchMove as any);
    };
  }, [isScrollLocked, isVideoExpanded, scrollProgress, accumulatedScroll]);

  // Calculate video dimensions based on scroll progress
  const baseWidth = 400;
  const baseHeight = 300;
  const fullScreenWidth = window.innerWidth;
  const fullScreenHeight = window.innerHeight;
  
  // Smooth transition to full screen
  const videoWidth = baseWidth + (fullScreenWidth - baseWidth) * scrollProgress;
  const videoHeight = baseHeight + (fullScreenHeight - baseHeight) * scrollProgress;

  // Split title into words for animation
  const titleWords = title ? title.split(' ') : [];
  const firstWord = titleWords[0] || '';
  const restOfTitle = titleWords.slice(1).join(' ') || '';

  return (
    <div className="min-h-screen">
      {/* Books section with scroll-to-expand video - NO TRANSITION SECTION */}
      <div
        ref={sectionRef}
        className="min-h-screen relative overflow-hidden"
        style={{
          backgroundImage: `url(${bgImageSrc})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed'
        }}
      >
        {/* Background overlay */}
        <div className="absolute inset-0 bg-black/40" />
        
        {/* Content container */}
        <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-8">
          
          {/* Video container with overlay text */}
          <div className="relative flex flex-col items-center">
            
            {/* Video that expands with scroll */}
            <motion.div
              className="relative rounded-2xl overflow-hidden shadow-2xl"
              style={{
                width: `${videoWidth}px`,
                height: `${videoHeight}px`,
                maxWidth: '100vw',
                maxHeight: '100vh'
              }}
              animate={{
                scale: isVideoExpanded ? 1 : 1,
                borderRadius: scrollProgress > 0.8 ? '0px' : '16px'
              }}
              transition={{ duration: 0.3 }}
            >
              {mediaType === 'video' ? (
                <video
                  ref={videoRef}
                  src={mediaSrc}
                  poster={posterSrc}
                  autoPlay
                  muted
                  loop
                  playsInline
                  className="w-full h-full object-cover"
                  style={{ display: 'block' }}
                />
              ) : (
                <img
                  src={mediaSrc}
                  alt={title || 'Media content'}
                  className="w-full h-full object-cover"
                />
              )}
              
              {/* Video overlay that fades as video expands */}
              <motion.div
                className="absolute inset-0 bg-black/20"
                animate={{ opacity: 0.3 - scrollProgress * 0.3 }}
                transition={{ duration: 0.2 }}
              />

              {/* Overlay text that moves with scroll - POSITIONED OVER VIDEO */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                {/* First word moves left */}
                <motion.h2
                  className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-2"
                  style={{ 
                    fontFamily: "'Poppins', sans-serif",
                    textShadow: '2px 2px 4px rgba(0,0,0,0.8)',
                    transform: `translateX(-${scrollProgress * 200}px)`,
                    opacity: Math.max(1 - scrollProgress * 1.2, 0)
                  }}
                >
                  {firstWord}
                </motion.h2>
                
                {/* Rest of title moves right */}
                <motion.h2
                  className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-4"
                  style={{ 
                    fontFamily: "'Poppins', sans-serif",
                    textShadow: '2px 2px 4px rgba(0,0,0,0.8)',
                    transform: `translateX(${scrollProgress * 200}px)`,
                    opacity: Math.max(1 - scrollProgress * 1.2, 0)
                  }}
                >
                  {restOfTitle}
                </motion.h2>
                
                {/* Tagline fades out */}
                {date && (
                  <motion.p
                    className="text-xl md:text-2xl text-blue-200 font-medium italic text-center px-4"
                    style={{ 
                      fontFamily: "'Inter', sans-serif",
                      textShadow: '1px 1px 2px rgba(0,0,0,0.8)',
                      opacity: Math.max(1 - scrollProgress * 1.5, 0)
                    }}
                  >
                    {date}
                  </motion.p>
                )}
              </div>
            </motion.div>

            {/* Scroll instruction - positioned below video */}
            {!isVideoExpanded && (
              <motion.div
                className="mt-8 text-center"
                animate={{ opacity: Math.max(1 - scrollProgress * 2, 0) }}
              >
                <p className="text-white/80 text-sm" style={{ fontFamily: "'Inter', sans-serif" }}>
                  Scroll to expand video
                </p>
              </motion.div>
            )}
          </div>

          {/* Content that appears after video expands */}
          <motion.div
            className="mt-12 w-full max-w-4xl"
            initial={{ opacity: 0, y: 50 }}
            animate={{ 
              opacity: showContent ? 1 : 0,
              y: showContent ? 0 : 50
            }}
            transition={{ duration: 0.7, delay: 0.3 }}
          >
            {children}
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default ScrollExpandMedia;